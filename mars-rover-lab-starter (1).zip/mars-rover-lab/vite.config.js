import { defineConfig } from 'vite';

export default defineConfig({
  base: '/mars-rover-lab/',
});
