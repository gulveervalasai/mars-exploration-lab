import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import './style.css';
import { createTerrain, terrainHeight } from './terrain.js';
import { createRover, updateRoverGrounding } from './rover.js';
import { findPath } from './astar.js';

const container = document.querySelector('#scene-container');
const scene = new THREE.Scene();
scene.background = new THREE.Color('#a96543');
scene.fog = new THREE.Fog('#a96543', 35, 105);
const camera = new THREE.PerspectiveCamera(55, container.clientWidth / container.clientHeight, .1, 250);
camera.position.set(10, 11, 16);
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.setSize(container.clientWidth, container.clientHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
container.appendChild(renderer.domElement);
const controls = new OrbitControls(camera, renderer.domElement);
controls.target.set(0, 1, 0); controls.enableDamping = true; controls.maxPolarAngle = Math.PI * .48;
scene.add(new THREE.HemisphereLight('#ffe0bd', '#4a281c', 2.1));
const sun = new THREE.DirectionalLight('#fff0d7', 3.2); sun.position.set(-20, 35, 12); sun.castShadow = true; sun.shadow.mapSize.set(2048,2048); scene.add(sun);
createTerrain(scene);
const rover = createRover(scene);

const waypoint = { x: 18, z: -16 };
const marker = new THREE.Mesh(new THREE.CylinderGeometry(.22,.22,.12,24), new THREE.MeshStandardMaterial({color:'#71d69b', emissive:'#174b2e'}));
marker.position.set(waypoint.x, terrainHeight(waypoint.x,waypoint.z)+.2, waypoint.z); scene.add(marker);
const beacon = new THREE.Mesh(new THREE.CylinderGeometry(.035,.035,1.7,8), new THREE.MeshStandardMaterial({color:'#b8f3c9', emissive:'#28663d'}));
beacon.position.set(waypoint.x, marker.position.y+.8, waypoint.z); scene.add(beacon);

let mode = 'manual', drive = {forward:false,backward:false,left:false,right:false}, path = [], pathIndex = 0, distance = 0, battery = 98, last = performance.now(), elapsed = 0;
const log = msg => { const el = document.querySelector('#event-log'); const p = document.createElement('p'); p.innerHTML = `<time>${String(Math.floor(elapsed/60)).padStart(2,'0')}:${String(Math.floor(elapsed%60)).padStart(2,'0')}</time> ${msg}`; el.prepend(p); while(el.children.length>5) el.lastChild.remove(); };
function setMode(next) {
  mode = next;
  document.querySelector('#manual-btn').classList.toggle('active', next==='manual');
  document.querySelector('#auto-btn').classList.toggle('active', next==='auto');
  document.querySelector('#auto-drive').disabled = next !== 'auto';
  document.querySelector('#control-help').textContent = next==='manual' ? 'Use WASD or arrow keys to drive the rover.' : 'Plan a route to the survey waypoint.';
  log(`${next==='manual'?'Manual':'Autonomous'} control selected.`);
}
document.querySelector('#manual-btn').onclick = () => setMode('manual');
document.querySelector('#auto-btn').onclick = () => setMode('auto');
document.querySelector('#auto-drive').onclick = () => {
  path = findPath({x:rover.position.x,z:rover.position.z}, waypoint);
  pathIndex = 0;
  if (!path.length) { log('No safe route found. Try again from another position.'); return; }
  log(`Autonomous route planned: ${path.length} waypoints.`);
};
document.querySelectorAll('[data-drive]').forEach(btn => {
  const action = btn.dataset.drive;
  btn.addEventListener('pointerdown', e => { e.preventDefault(); if(action==='stop') drive={forward:false,backward:false,left:false,right:false}; else drive[action]=true; });
  for (const ev of ['pointerup','pointerleave','pointercancel']) btn.addEventListener(ev,()=>{drive[action]=false;});
});
window.addEventListener('keydown', e => {
  const map = {w:'forward',ArrowUp:'forward',s:'backward',ArrowDown:'backward',a:'left',ArrowLeft:'left',d:'right',ArrowRight:'right'};
  const k = map[e.key] || map[e.key.toLowerCase()];
  if(k && mode==='manual'){drive[k]=true;e.preventDefault();}
});
window.addEventListener('keyup', e => {
  const map = {w:'forward',ArrowUp:'forward',s:'backward',ArrowDown:'backward',a:'left',ArrowLeft:'left',d:'right',ArrowRight:'right'};
  const k = map[e.key] || map[e.key.toLowerCase()]; if(k) drive[k]=false;
});
function updateTelemetry(speed) {
  document.querySelector('#speed').innerHTML = `${speed.toFixed(1)} <i>m/s</i>`;
  document.querySelector('#battery').innerHTML = `${Math.max(0,battery).toFixed(0)} <i>%</i>`;
  document.querySelector('#battery-bar').style.width = `${battery}%`;
  const deg = (THREE.MathUtils.radToDeg(rover.rotation.y)+360)%360;
  document.querySelector('#heading').textContent = `${String(Math.round(deg)).padStart(3,'0')}°`;
  document.querySelector('#distance').innerHTML = `${distance.toFixed(1)} <i>m</i>`;
  document.querySelector('#position').textContent = `X ${rover.position.x.toFixed(1)} · Z ${rover.position.z.toFixed(1)}`;
}
function animate(now) {
  requestAnimationFrame(animate);
  const dt = Math.min((now-last)/1000,.05); last=now; elapsed+=dt;
  let speed = 0;
  if (mode==='manual') {
    const throttle = (drive.forward?1:0)-(drive.backward?1:0);
    const steer = (drive.left?1:0)-(drive.right?1:0);
    if(throttle){ rover.rotation.y += steer*dt*1.35; const old=rover.position.clone(); rover.position.x += Math.sin(rover.rotation.y)*throttle*dt*3.2; rover.position.z += Math.cos(rover.rotation.y)*throttle*dt*3.2; rover.position.x=THREE.MathUtils.clamp(rover.position.x,-46,46); rover.position.z=THREE.MathUtils.clamp(rover.position.z,-46,46); updateRoverGrounding(rover); distance += rover.position.distanceTo(old); speed=3.2; }
  } else if(path.length && pathIndex<path.length) {
    const target=path[pathIndex], dx=target.x-rover.position.x, dz=target.z-rover.position.z, d=Math.hypot(dx,dz);
    if(d<.65){pathIndex++;} else {rover.rotation.y=Math.atan2(dx,dz); const step=Math.min(d,dt*2.1); rover.position.x += dx/d*step; rover.position.z += dz/d*step; updateRoverGrounding(rover); distance+=step; speed=2.1;}
    if(pathIndex>=path.length){path=[];log('Survey waypoint reached. Objective complete.');document.querySelector('#waypoint-state').textContent='COMPLETE';}
  }
  rover.userData.wheels.forEach(w=>{w.rotation.z -= speed*dt*1.6;});
  if(speed>0) battery=Math.max(0,battery-dt*.018);
  updateTelemetry(speed);
  controls.target.lerp(new THREE.Vector3(rover.position.x,rover.position.y+1,rover.position.z),.04);
  controls.update(); renderer.render(scene,camera);
}
requestAnimationFrame(animate);
new ResizeObserver(() => { const w=container.clientWidth,h=container.clientHeight; camera.aspect=w/h; camera.updateProjectionMatrix(); renderer.setSize(w,h); }).observe(container);
log('Procedural terrain generated.');
