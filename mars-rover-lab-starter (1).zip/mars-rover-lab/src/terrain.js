import * as THREE from 'three';

function hash(x, z) {
  const n = Math.sin(x * 127.1 + z * 311.7) * 43758.5453;
  return n - Math.floor(n);
}
function smoothNoise(x, z) {
  const ix = Math.floor(x), iz = Math.floor(z), fx = x - ix, fz = z - iz;
  const ux = fx * fx * (3 - 2 * fx), uz = fz * fz * (3 - 2 * fz);
  const a = hash(ix, iz), b = hash(ix + 1, iz), c = hash(ix, iz + 1), d = hash(ix + 1, iz + 1);
  return THREE.MathUtils.lerp(THREE.MathUtils.lerp(a, b, ux), THREE.MathUtils.lerp(c, d, ux), uz);
}
export function terrainHeight(x, z) {
  const broad = (smoothNoise(x * .035, z * .035) - .5) * 5.5;
  const medium = (smoothNoise(x * .12 + 20, z * .12) - .5) * 1.6;
  const fine = (smoothNoise(x * .32, z * .32 + 40) - .5) * .28;
  const crater = -Math.exp(-((x + 7) ** 2 + (z - 4) ** 2) / 85) * 2.8;
  return broad + medium + fine + crater;
}
export function createTerrain(scene) {
  const size = 100, segments = 180;
  const geometry = new THREE.PlaneGeometry(size, size, segments, segments);
  geometry.rotateX(-Math.PI / 2);
  const pos = geometry.attributes.position;
  const colors = [];
  const c1 = new THREE.Color('#a95d3d'), c2 = new THREE.Color('#d18a5e'), c3 = new THREE.Color('#70402f');
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i), z = pos.getZ(i), y = terrainHeight(x, z);
    pos.setY(i, y);
    const n = smoothNoise(x * .19 + 2, z * .19 + 7);
    const color = c1.clone().lerp(c2, Math.max(0, Math.min(1, n * .8)));
    if (y < -1.5) color.lerp(c3, .35);
    colors.push(color.r, color.g, color.b);
  }
  geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
  geometry.computeVertexNormals();
  const ground = new THREE.Mesh(geometry, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 1 }));
  ground.receiveShadow = true; scene.add(ground);

  const rockMat = new THREE.MeshStandardMaterial({ color: '#82503b', roughness: 1 });
  let seed = 19;
  const rand = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
  for (let i = 0; i < 190; i++) {
    const x = (rand() - .5) * 88, z = (rand() - .5) * 88;
    if (Math.hypot(x, z) < 5) continue;
    const r = .12 + rand() * .55;
    const rock = new THREE.Mesh(new THREE.DodecahedronGeometry(r, 0), rockMat);
    rock.position.set(x, terrainHeight(x, z) + r * .45, z);
    rock.rotation.set(rand() * 2, rand() * 3, rand() * 2);
    rock.scale.set(1 + rand(), .55 + rand() * .5, .8 + rand() * .7);
    rock.castShadow = true; rock.receiveShadow = true; scene.add(rock);
  }
}
