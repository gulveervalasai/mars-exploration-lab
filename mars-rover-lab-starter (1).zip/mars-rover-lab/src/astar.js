import { terrainHeight } from './terrain.js';

const key = (x, z) => `${x},${z}`;
export function findPath(start, goal, step = 2) {
  const toCell = p => ({ x: Math.round(p.x / step), z: Math.round(p.z / step) });
  const s = toCell(start), g = toCell(goal);
  const open = [s], came = new Map(), gScore = new Map([[key(s.x, s.z), 0]]);
  const fScore = new Map([[key(s.x, s.z), Math.hypot(g.x - s.x, g.z - s.z)]]);
  const closed = new Set();
  const dirs = [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]];
  while (open.length) {
    open.sort((a,b) => (fScore.get(key(a.x,a.z)) ?? Infinity) - (fScore.get(key(b.x,b.z)) ?? Infinity));
    const current = open.shift(), ck = key(current.x,current.z);
    if (current.x === g.x && current.z === g.z) {
      const path = [current]; let k = ck;
      while (came.has(k)) { const prev = came.get(k); path.unshift(prev); k = key(prev.x,prev.z); }
      return path.map(p => ({ x: p.x * step, z: p.z * step }));
    }
    closed.add(ck);
    for (const [dx,dz] of dirs) {
      const n = { x: current.x + dx, z: current.z + dz }, nk = key(n.x,n.z);
      if (closed.has(nk) || Math.abs(n.x * step) > 44 || Math.abs(n.z * step) > 44) continue;
      const h1 = terrainHeight(current.x * step, current.z * step), h2 = terrainHeight(n.x * step, n.z * step);
      const slope = Math.abs(h2 - h1) / step;
      if (slope > .65) continue;
      const tentative = (gScore.get(ck) ?? Infinity) + Math.hypot(dx,dz) + slope * 2;
      if (tentative < (gScore.get(nk) ?? Infinity)) {
        came.set(nk, current); gScore.set(nk, tentative);
        fScore.set(nk, tentative + Math.hypot(g.x - n.x, g.z - n.z));
        if (!open.some(p => p.x === n.x && p.z === n.z)) open.push(n);
      }
    }
  }
  return [];
}
