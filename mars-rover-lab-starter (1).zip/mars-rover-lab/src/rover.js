import * as THREE from 'three';
import { terrainHeight } from './terrain.js';

export function createRover(scene) {
  const rover = new THREE.Group();
  const bodyMat = new THREE.MeshStandardMaterial({ color: '#d9d1c2', roughness: .7, metalness: .25 });
  const darkMat = new THREE.MeshStandardMaterial({ color: '#35383a', roughness: .85 });
  const goldMat = new THREE.MeshStandardMaterial({ color: '#b58a43', metalness: .6, roughness: .35 });
  const body = new THREE.Mesh(new THREE.BoxGeometry(2.35, .48, 1.55), bodyMat);
  body.position.y = 1.25; body.castShadow = true; rover.add(body);
  const deck = new THREE.Mesh(new THREE.BoxGeometry(1.9, .12, 1.3), goldMat);
  deck.position.y = 1.53; rover.add(deck);
  const instrument = new THREE.Mesh(new THREE.BoxGeometry(.7, .24, .65), darkMat);
  instrument.position.set(-.25, 1.72, 0); rover.add(instrument);
  const mast = new THREE.Group(); mast.position.set(.65, 1.5, 0); rover.add(mast);
  const pole = new THREE.Mesh(new THREE.CylinderGeometry(.055, .07, 1.05, 10), bodyMat); pole.position.y = .55; mast.add(pole);
  const camera = new THREE.Mesh(new THREE.BoxGeometry(.48, .28, .32), darkMat); camera.position.set(.05, 1.1, 0); mast.add(camera);
  const lens = new THREE.Mesh(new THREE.CylinderGeometry(.09, .09, .07, 16), goldMat); lens.rotation.z = Math.PI / 2; lens.position.set(.3, 1.1, 0); mast.add(lens);
  const wheels = [];
  for (const x of [-.78, 0, .78]) for (const z of [-.92, .92]) {
    const wheel = new THREE.Group(); wheel.position.set(x, .62, z); wheel.rotation.x = Math.PI / 2;
    const tire = new THREE.Mesh(new THREE.CylinderGeometry(.48, .48, .28, 20), darkMat); tire.castShadow = true; wheel.add(tire);
    const hub = new THREE.Mesh(new THREE.CylinderGeometry(.2, .2, .3, 16), goldMat); wheel.add(hub);
    for (let j = 0; j < 12; j++) {
      const tread = new THREE.Mesh(new THREE.BoxGeometry(.16, .12, .32), bodyMat);
      const a = j * Math.PI / 6; tread.position.set(Math.cos(a) * .47, Math.sin(a) * .47, 0); tread.rotation.z = a; wheel.add(tread);
    }
    rover.add(wheel); wheels.push(wheel);
  }
  rover.position.set(0, terrainHeight(0, 0), 0);
  rover.userData.wheels = wheels;
  scene.add(rover);
  return rover;
}

export function updateRoverGrounding(rover) {
  const y = terrainHeight(rover.position.x, rover.position.z);
  rover.position.y = y;
}
