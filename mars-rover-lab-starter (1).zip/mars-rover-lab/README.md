# MARS ROVER LAB

An independent educational 3D Mars rover simulator built with Vite and Three.js.

## Features
- Procedurally generated Mars-like terrain with hills, crater depression, and scattered rocks
- Detailed six-wheel rover model
- Manual keyboard and on-screen controls
- Basic autonomous route planning using A*
- Live telemetry dashboard

## Requirements
- Node.js 20.19+ or 22.12+
- npm

## Run locally
```bash
npm install
npm run dev
```
Open the local URL printed by Vite (usually http://localhost:5173).

## Production build
```bash
npm run build
npm run preview
```

## Deploy to GitHub Pages
The Vite base path is configured for the repository name `mars-rover-lab`.
1. Push this project to a GitHub repository named `mars-rover-lab`.
2. Open Settings → Pages.
3. Set Build and deployment source to **GitHub Actions**.
4. The workflow in `.github/workflows/deploy.yml` builds and deploys the site.

Your URL will be `https://YOUR-USERNAME.github.io/mars-rover-lab/`.

## Controls
- W / Up Arrow: forward
- S / Down Arrow: reverse
- A / Left Arrow: steer left
- D / Right Arrow: steer right
- Drag: orbit camera
- Scroll: zoom

## Important note
This is a learning prototype. Terrain is procedurally generated and rover movement is simplified. It does not use validated Mars elevation data, validated rover dynamics, or official NASA systems. It is not affiliated with NASA.
